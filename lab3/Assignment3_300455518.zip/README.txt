Student Name: Henry Dowd
Student Number: 300455518
Course Code: CSI2372A

Card object with color and suit, method to detect pairs of cards and a linked list structure with associated methods.
