Student Name: Henry Dowd
Student Number: 300455518
Course Code: CSI2372A

Files requested for Lab2, 4 .cpp files and 2 .h files.
All completed except for Ex1 as i was unsure what the question was asking for, i attempted it regardless.
Thank You
